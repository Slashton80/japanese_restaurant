package info.hccis.performance;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerformanceHallApplicationTests {

    @Test
    void test(){
        System.out.println("BJM-Testing to see if this test will run when the project starts");
        //Assertions.assertEquals("1","2");
    }
    
//	@Test
//	void contextLoads() {
//	}

}
